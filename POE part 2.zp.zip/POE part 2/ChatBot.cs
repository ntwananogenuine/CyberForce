﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Documents;
using System.Windows.Media;

namespace POE2
{
    public class ChatBot
    {
        private respond keywords;
        private SentimentDetector sentiment;
        private MemoryStore memory;

        private bool _awaitingName = true;
        private string _lastTopic = "";

        public ChatBot()
        {
            keywords = new respond();
            sentiment = new SentimentDetector();
            // Try to load persisted memory from AppData; fall back to new memory
            try
            {
                var appDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CyberForce");
                memory = MemoryStore.Load(appDir);
            }
            catch
            {
                memory = new MemoryStore();
            }
            // If a username was restored from persistent storage, we are not awaiting a name
            if (!string.IsNullOrWhiteSpace(memory.UserName))
            {
                _awaitingName = false;
            }
        }

        public string GetGreeting()
        {
            return "Hello! What is your name?";
        }

        // Public API to set username (avoids reflection from callers)
        public void SetUserName(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return;

            memory.UserName = name.Trim();
            _awaitingName = false;

            // persist memory
            try
            {
                var appDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CyberForce");
                memory.Save(appDir);
                // also append a record to user_names.txt for auditing
                SaveUserInfo();
            }
            catch { }
        }

        // Check if provided name matches stored memory
        public bool IsKnownUser(string name)
        {
            if (string.IsNullOrWhiteSpace(name))
                return false;

            return string.Equals(memory.UserName, name, StringComparison.OrdinalIgnoreCase);
        }

        // Expose personalised opener
        public string GetPersonalisedOpener()
        {
            return memory.GetPersonalisedOpener();
        }

        // Persist a record of the current user info to user_names.txt in AppData/CyberForce
        public void SaveUserInfo()
        {
            try
            {
                var line = string.Format("{0}\t{1}\t{2}", DateTime.UtcNow.ToString("o"), memory?.UserName ?? string.Empty, memory?.FavouriteTopic ?? string.Empty);

                // Primary location: AppData\CyberForce\user_names.txt
                var appDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "CyberForce");
                if (!Directory.Exists(appDir))
                    Directory.CreateDirectory(appDir);

                var fileAppData = Path.Combine(appDir, "user_names.txt");
                File.AppendAllText(fileAppData, line + Environment.NewLine);

                // Also write to the current application's folder for convenience (relative filename)
                try
                {
                    var fileLocal = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "user_names.txt");
                    File.AppendAllText(fileLocal, line + Environment.NewLine);
                }
                catch
                {
                    // ignore local write failures
                }
            }
            catch
            {
                // Swallow IO exceptions to avoid breaking the UI
            }
        }

        public string ProcessInput(string input)
        {
            if (input == null)
                input = string.Empty;

            var lowerInput = input.ToLowerInvariant();

            if (_awaitingName)
            {
                memory.UserName = lowerInput;

                _awaitingName = false;

                return $"Nice to meet you {memory.UserName}! Ask me anything about cybersecurity.";
            }

            if (lowerInput.Contains("tell me more") || lowerInput.Contains("explain more"))
            {
                if (!string.IsNullOrEmpty(_lastTopic))
                {
                    return $"Here is more information about {_lastTopic}: Always stay alert and keep learning about cybersecurity threats.";
                }
            }

            Sentiment sentimentResult = sentiment.Detect(lowerInput);
            string sentimentResponse = sentiment.GetSentimentResponse(sentimentResult);

            string keywordResponse = keywords.GetResponse(lowerInput);

            if (keywordResponse != null)
            {
                foreach (string keyword in keywords.GetAllKeywords())
                {
                    if (lowerInput.Contains(keyword))
                    {
                        _lastTopic = keyword;

                        memory.FavouriteTopic = keyword;

                        break;
                    }
                }

                string personalised = "";

                if (!string.IsNullOrEmpty(memory.FavouriteTopic))
                {
                    personalised = $"As someone interested in {memory.FavouriteTopic}, ";
                }

                return $"{sentimentResponse} {personalised}{keywordResponse}";
            }

            // If there's no keyword-based response but we detected a sentiment,
            // return the sentiment response so the bot acknowledges the user's feeling.
            if (!string.IsNullOrEmpty(sentimentResponse) && sentimentResult != Sentiment.Neutral)
            {
                return sentimentResponse;
            }

            if (lowerInput.Contains("how are you"))
            {
                return "I am functioning perfectly and ready to help you stay safe online.";
            }

            if (lowerInput.Contains("what can you do"))
            {
                return "I can help with phishing, malware, passwords, scams, and privacy tips.";
            }

            if (lowerInput.Contains("purpose"))
            {
                return "My purpose is to educate users about cybersecurity awareness.";
            }

            return "I did not understand that. Try asking about passwords, phishing, scams, malware, or privacy.";
        }
    }

    public class MemoryStore
    {
        private Dictionary<string, string> _memory = new Dictionary<string, string>();

        public string UserName { get; set; }

        public string FavouriteTopic { get; set; }

        public void Store(string key, string value)
        {
            _memory[key] = value;
        }

        public string Recall(string key)
        {
            if (_memory.ContainsKey(key))
            {
                return _memory[key];
            }

            return null;
        }

        public string GetPersonalisedOpener()
        {
            return $"Welcome back {UserName}.";
        }

        // Persist/load helpers
        public void Save(string folderPath)
        {
            try
            {
                if (!Directory.Exists(folderPath))
                    Directory.CreateDirectory(folderPath);

                var file = Path.Combine(folderPath, "memory.txt");
                File.WriteAllText(file, UserName ?? "");
            }
            catch { }
        }

        public static MemoryStore Load(string folderPath)
        {
            try
            {
                var ms = new MemoryStore();
                var file = Path.Combine(folderPath, "memory.txt");
                if (File.Exists(file))
                {
                    ms.UserName = File.ReadAllText(file).Trim();
                }

                return ms;
            }
            catch
            {
                return new MemoryStore();
            }
        }
    }
}
